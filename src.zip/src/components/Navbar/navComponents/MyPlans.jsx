import React from "react";

const MyPlans = () => {
  return <div>MyPlans</div>;
};

export default MyPlans;
