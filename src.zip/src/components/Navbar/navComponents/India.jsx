import React from 'react'

const India = () => {
  return (
    <div>India</div>
  )
}

export default India