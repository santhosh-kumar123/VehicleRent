// import React from "react";
// import Styles from "../navbar.module.css"
// const MyProfile = () => {
//   return (
//     <div style={{position:"absolute",marginLeft:"1580px",marginTop:"-20px"}}>
//       {/* <ul>
//         <li>
//           <Link>MyProfile</Link>
//         </li>
//         <li>
//           <Link>My Booking</Link>
//         </li>
//         <li>
//           <Link>My Co-Drivers</Link>
//         </li>
//         <li>
//           <Link>My Wallet</Link>
//         </li>
//         <li>
//           <Link>My Bank Details</Link>
//         </li>
//         <li>
//           <Link>Change Password</Link>
//         </li>
//         <li>
//           <Link>Log out</Link>
//         </li>
//       </ul> */}
//       <input className={Styles.me={Styles.myprofile} type="text" placeholder="profile" list="h" style={{width:"100px",height:"30px",textAlign:"center",fontSize:"20px"}} />
//       <datalist id="h">
//         <option value="MyProfile">MyProfile</option>
//         <option value="My Booking">My Booking</option>
//         <option value="My Co-Drivers">My Co-Drivers</option>
//         <option value="My Wallet">My Wallet</option>
//         <option value="My Bank Details">My Bank Details</option>
//         <option value="Change Password">Change Password</option>
//         <option value="Log out">Log out</option>
//       </datalist>
//     </div>
//   );
// };

// export default MyProfile;

import React from "react";
import Styles from "./myprofile.module.css";

const MyProfile = () => {
  return (
    <div className={Styles.signupFrm}>
      <form action="" className={Styles.form}>
        <h1 className={Styles.title}>Sign up</h1>

        <div className={Styles.inputContainer}>
          <input type="text" className={Styles.input} placeholder="a" />
          <label for="" className={Styles.label}>
            Email
          </label>
        </div>

        <div className={Styles.inputContainer}>
          <input type="text" className={Styles.input} placeholder="a" />
          <label for="" className={Styles.label}>
            Username
          </label>
        </div>

        <div className={Styles.inputContainer}>
          <input type="text" className={Styles.input} placeholder="a" />
          <label for="" className={Styles.label}>
            Password
          </label>
        </div>

        <div className={Styles.inputContainer}>
          <input type="text" className={Styles.input} placeholder="a" />
          <label for="" className={Styles.label}>
            Confirm Password
          </label>
        </div>

        <input type="submit" className={Styles.submitBtn} value="Sign up" />
      </form>
    </div>
  );
};

export default MyProfile;
