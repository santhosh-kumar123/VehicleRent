import React from "react";

const MyOffers = () => {
  return <div>MyOffers</div>;
};

export default MyOffers;
