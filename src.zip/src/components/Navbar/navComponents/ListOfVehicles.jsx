import React from "react";

const ListOfVehicles = () => {
  return <div>ListOfVehicles</div>;
};

export default ListOfVehicles;
