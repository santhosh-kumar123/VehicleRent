import React from "react";

const Home = () => {
    return (
      <div
        style={{
          position: "absolute",
          left: 0,
          top: "0",
          marginLeft: "50px",
        }}
        className="text-3xl font-bold underline"
      >
        Home
      </div>
    );
};

export default Home;
