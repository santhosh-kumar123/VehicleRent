import axios from "axios";
import React, { useState } from "react";
import { useEffect } from "react";
import { Axios } from "../Apis/Axios";

const Delete = () => {
  let [user, setUser] = useState([]);
  let fetchUser = async () => {
    let { data } = await Axios.get("users");
    setUser(data);
    console.log(data);
  };
  useEffect(() => {
    fetchUser();
  }, []);
  let handleEdit = id => {
    window.location.assign(`/Edit/${id}`);
  };
  let handleclick = id => {
    try {
      Axios.delete(`users/${id}`);
    } catch (error) {
      console.log(error);
    }
    window.location.assign("/Delete");
  };
  return (
    <div>
      <table border={1} cellPadding="10px" cellSpacing="0px">
        <thead>
          <th>Car Name :</th>
          <th>Car Type </th>
          <th>Car Model</th>
          <th>Car Rent Price :</th>
          <th>Car Photos </th>
        </thead>
        <tbody>
          {user.map(val => {
            let { id, name, salary, company } = val;
            return (
              <tr key={id}>
                <td>{name}</td>
                <td>{salary}</td>
                <td>{company}</td>
                <td>{salary}</td>
                <td>{company}</td>
                <td onClick={() => handleEdit(id)}>Edit</td>
                <td onClick={() => handleclick(id)}>Delete</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default Delete;
