import React from "react";
import { Link } from "react-router-dom";
const CrudNavbar = () => {
  return (
    <ul>
      <li>
        {" "}
        <Link to="/Create">Create</Link>
      </li>
      <li>
        <Link to="/Delete">Delete</Link>
      </li>
      <li>
        <Link to="/Edit/:id">Edit</Link>
      </li>
    </ul>
  );
};

export default CrudNavbar;
